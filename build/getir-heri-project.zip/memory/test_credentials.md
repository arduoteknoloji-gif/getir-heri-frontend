# Test Credentials for getir-heri

## Admin Account
- Email: admin@getir-heri.com
- Password: admin123
- Role: admin

## Test Courier Account
- Email: courier@test.com
- Password: courier123
- Role: courier

## Test Restaurant Account
- Email: restaurant@test.com
- Password: restaurant123
- Role: restaurant

## Auth Endpoints
- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/logout
- GET /api/auth/me
- POST /api/auth/refresh
