from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import List, Optional, Literal
from datetime import datetime, timezone, timedelta
import os
import logging
import bcrypt
import jwt

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# JWT Configuration
JWT_ALGORITHM = "HS256"

def get_jwt_secret() -> str:
    return os.environ["JWT_SECRET"]

def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode("utf-8"), salt)
    return hashed.decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))

def create_access_token(user_id: str, email: str) -> str:
    payload = {
        "sub": user_id,
        "email": email,
        "exp": datetime.now(timezone.utc) + timedelta(minutes=15),
        "type": "access"
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
        "type": "refresh"
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        user["_id"] = str(user["_id"])
        user.pop("password_hash", None)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Pydantic Models
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: Literal["courier", "restaurant", "admin"]
    phone: Optional[str] = None
    restaurant_name: Optional[str] = None
    
    @field_validator('password')
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError('Password must be at least 6 characters')
        return v

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str = Field(alias="_id")
    email: str
    name: str
    role: str
    phone: Optional[str] = None
    restaurant_name: Optional[str] = None
    restaurant_id: Optional[str] = None
    created_at: datetime

    class Config:
        populate_by_name = True

class OrderCreate(BaseModel):
    restaurant_id: str
    customer_name: str
    customer_phone: str
    customer_address: str
    customer_lat: float
    customer_lng: float
    pickup_address: str
    pickup_lat: float
    pickup_lng: float
    items: List[dict]
    total_amount: float
    delivery_fee: float
    notes: Optional[str] = None

class OrderUpdate(BaseModel):
    status: Optional[Literal["pending", "assigned", "picked_up", "in_transit", "delivered", "cancelled"]] = None
    courier_lat: Optional[float] = None
    courier_lng: Optional[float] = None

class OrderResponse(BaseModel):
    id: str
    restaurant_id: str
    restaurant_name: Optional[str] = None
    courier_id: Optional[str] = None
    courier_name: Optional[str] = None
    customer_name: str
    customer_phone: str
    customer_address: str
    customer_lat: float
    customer_lng: float
    pickup_address: str
    pickup_lat: float
    pickup_lng: float
    items: List[dict]
    total_amount: float
    delivery_fee: float
    status: str
    notes: Optional[str] = None
    courier_lat: Optional[float] = None
    courier_lng: Optional[float] = None
    created_at: datetime
    updated_at: datetime

class MessageCreate(BaseModel):
    order_id: str
    message: str

class MessageResponse(BaseModel):
    id: str
    order_id: str
    sender_id: str
    sender_name: str
    sender_role: str
    message: str
    created_at: datetime

class LocationUpdate(BaseModel):
    lat: float
    lng: float

# Auth Routes
@api_router.post("/auth/register")
async def register(req: RegisterRequest, response: Response):
    email_lower = req.email.lower()
    
    existing = await db.users.find_one({"email": email_lower})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_doc = {
        "email": email_lower,
        "password_hash": hash_password(req.password),
        "name": req.name,
        "role": req.role,
        "phone": req.phone,
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc)
    }
    
    # If restaurant, create restaurant record
    if req.role == "restaurant" and req.restaurant_name:
        restaurant_doc = {
            "name": req.restaurant_name,
            "owner_email": email_lower,
            "address": "",
            "phone": req.phone or "",
            "created_at": datetime.now(timezone.utc)
        }
        restaurant_result = await db.restaurants.insert_one(restaurant_doc)
        user_doc["restaurant_id"] = str(restaurant_result.inserted_id)
        user_doc["restaurant_name"] = req.restaurant_name
    
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    access_token = create_access_token(user_id, email_lower)
    refresh_token = create_refresh_token(user_id)
    
    response.set_cookie(
        key="access_token", value=access_token, httponly=True,
        secure=False, samesite="lax", max_age=900, path="/"
    )
    response.set_cookie(
        key="refresh_token", value=refresh_token, httponly=True,
        secure=False, samesite="lax", max_age=604800, path="/"
    )
    
    user_doc["_id"] = user_id
    user_doc.pop("password_hash")
    return user_doc

@api_router.post("/auth/login")
async def login(req: LoginRequest, response: Response, request: Request):
    email_lower = req.email.lower()
    
    # Check brute force
    identifier = f"{request.client.host}:{email_lower}"
    attempt = await db.login_attempts.find_one({"identifier": identifier})
    
    if attempt and attempt.get("count", 0) >= 5:
        lockout_until = attempt.get("lockout_until")
        if lockout_until and lockout_until > datetime.now(timezone.utc):
            raise HTTPException(status_code=429, detail="Too many failed attempts. Try again later.")
    
    user = await db.users.find_one({"email": email_lower})
    if not user or not verify_password(req.password, user["password_hash"]):
        # Increment failed attempts
        await db.login_attempts.update_one(
            {"identifier": identifier},
            {
                "$inc": {"count": 1},
                "$set": {
                    "lockout_until": datetime.now(timezone.utc) + timedelta(minutes=15)
                }
            },
            upsert=True
        )
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Clear failed attempts
    await db.login_attempts.delete_one({"identifier": identifier})
    
    user_id = str(user["_id"])
    access_token = create_access_token(user_id, email_lower)
    refresh_token = create_refresh_token(user_id)
    
    response.set_cookie(
        key="access_token", value=access_token, httponly=True,
        secure=False, samesite="lax", max_age=900, path="/"
    )
    response.set_cookie(
        key="refresh_token", value=refresh_token, httponly=True,
        secure=False, samesite="lax", max_age=604800, path="/"
    )
    
    user["_id"] = user_id
    user.pop("password_hash")
    return user

@api_router.post("/auth/logout")
async def logout(response: Response, user: dict = Depends(get_current_user)):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"message": "Logged out successfully"}

@api_router.get("/auth/me")
async def get_me(user: dict = Depends(get_current_user)):
    return user

@api_router.post("/auth/refresh")
async def refresh(request: Request, response: Response):
    token = request.cookies.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="Refresh token not found")
    
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        
        user_id = str(user["_id"])
        access_token = create_access_token(user_id, user["email"])
        
        response.set_cookie(
            key="access_token", value=access_token, httponly=True,
            secure=False, samesite="lax", max_age=900, path="/"
        )
        
        return {"message": "Token refreshed"}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Refresh token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

# Order Routes
@api_router.post("/orders", response_model=OrderResponse)
async def create_order(order: OrderCreate, user: dict = Depends(get_current_user)):
    if user["role"] not in ["restaurant", "admin"]:
        raise HTTPException(status_code=403, detail="Only restaurants can create orders")
    
    restaurant = await db.restaurants.find_one({"_id": ObjectId(order.restaurant_id)})
    if not restaurant:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    
    order_doc = {
        **order.model_dump(),
        "restaurant_name": restaurant.get("name", ""),
        "status": "pending",
        "courier_id": None,
        "courier_name": None,
        "courier_lat": None,
        "courier_lng": None,
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc)
    }
    
    result = await db.orders.insert_one(order_doc)
    order_doc["id"] = str(result.inserted_id)
    return order_doc

@api_router.get("/orders")
async def get_orders(
    status: Optional[str] = None,
    user: dict = Depends(get_current_user)
):
    query = {}
    
    if user["role"] == "courier":
        query["$or"] = [
            {"courier_id": user["_id"]},
            {"status": "pending"}
        ]
    elif user["role"] == "restaurant":
        query["restaurant_id"] = user.get("restaurant_id", "")
    
    if status:
        query["status"] = status
    
    orders = await db.orders.find(query).sort("created_at", -1).to_list(1000)
    
    for order in orders:
        # Convert ObjectId to string and set as id
        if "_id" in order:
            order["id"] = str(order["_id"])
            del order["_id"]
        if "created_at" in order and isinstance(order["created_at"], str):
            order["created_at"] = datetime.fromisoformat(order["created_at"])
        if "updated_at" in order and isinstance(order["updated_at"], str):
            order["updated_at"] = datetime.fromisoformat(order["updated_at"])
    
    return orders

@api_router.get("/orders/{order_id}")
async def get_order(order_id: str, user: dict = Depends(get_current_user)):
    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    order["id"] = str(order["_id"])
    order.pop("_id", None)
    return order

@api_router.patch("/orders/{order_id}")
async def update_order(
    order_id: str,
    update: OrderUpdate,
    user: dict = Depends(get_current_user)
):
    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc)
    
    await db.orders.update_one({"_id": ObjectId(order_id)}, {"$set": update_data})
    
    updated_order = await db.orders.find_one({"_id": ObjectId(order_id)})
    updated_order["id"] = str(updated_order["_id"])
    updated_order.pop("_id", None)
    return updated_order

@api_router.post("/orders/{order_id}/assign")
async def assign_courier(
    order_id: str,
    courier_id: str,
    user: dict = Depends(get_current_user)
):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Only admins can assign couriers")
    
    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    courier = await db.users.find_one({"_id": ObjectId(courier_id), "role": "courier"})
    if not courier:
        raise HTTPException(status_code=404, detail="Courier not found")
    
    await db.orders.update_one(
        {"_id": ObjectId(order_id)},
        {
            "$set": {
                "courier_id": courier_id,
                "courier_name": courier.get("name", ""),
                "status": "assigned",
                "updated_at": datetime.now(timezone.utc)
            }
        }
    )
    
    updated_order = await db.orders.find_one({"_id": ObjectId(order_id)})
    updated_order["id"] = str(updated_order["_id"])
    updated_order.pop("_id", None)
    return updated_order

@api_router.post("/orders/{order_id}/accept")
async def accept_order(order_id: str, user: dict = Depends(get_current_user)):
    if user["role"] != "courier":
        raise HTTPException(status_code=403, detail="Only couriers can accept orders")
    
    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    if order["status"] != "pending":
        raise HTTPException(status_code=400, detail="Order already assigned")
    
    await db.orders.update_one(
        {"_id": ObjectId(order_id)},
        {
            "$set": {
                "courier_id": user["_id"],
                "courier_name": user.get("name", ""),
                "status": "assigned",
                "updated_at": datetime.now(timezone.utc)
            }
        }
    )
    
    updated_order = await db.orders.find_one({"_id": ObjectId(order_id)})
    updated_order["id"] = str(updated_order["_id"])
    updated_order.pop("_id", None)
    return updated_order

# Courier Routes
@api_router.get("/couriers")
async def get_couriers(user: dict = Depends(get_current_user)):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Only admins can view all couriers")
    
    couriers = await db.users.find(
        {"role": "courier"},
        {"password_hash": 0, "_id": 0}
    ).to_list(1000)
    
    # Add active orders count
    for courier in couriers:
        courier_id = courier.get("id") or str(courier.get("_id", ""))
        active_count = await db.orders.count_documents({
            "courier_id": courier_id,
            "status": {"$in": ["assigned", "picked_up", "in_transit"]}
        })
        courier["active_orders"] = active_count
    
    return couriers

@api_router.patch("/couriers/{courier_id}/location")
async def update_courier_location(
    courier_id: str,
    location: LocationUpdate,
    user: dict = Depends(get_current_user)
):
    if user["role"] != "courier" or user["_id"] != courier_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    # Update courier's current location in user record
    await db.users.update_one(
        {"_id": ObjectId(courier_id)},
        {
            "$set": {
                "current_lat": location.lat,
                "current_lng": location.lng,
                "last_location_update": datetime.now(timezone.utc)
            }
        }
    )
    
    # Update all active orders with this courier
    await db.orders.update_many(
        {
            "courier_id": courier_id,
            "status": {"$in": ["assigned", "picked_up", "in_transit"]}
        },
        {
            "$set": {
                "courier_lat": location.lat,
                "courier_lng": location.lng
            }
        }
    )
    
    return {"message": "Location updated"}

@api_router.get("/couriers/{courier_id}/earnings")
async def get_courier_earnings(courier_id: str, user: dict = Depends(get_current_user)):
    if user["role"] != "courier" or user["_id"] != courier_id:
        if user["role"] != "admin":
            raise HTTPException(status_code=403, detail="Unauthorized")
    
    completed_orders = await db.orders.find({
        "courier_id": courier_id,
        "status": "delivered"
    }).to_list(1000)
    
    total_earnings = sum(order.get("delivery_fee", 0) for order in completed_orders)
    total_deliveries = len(completed_orders)
    
    return {
        "total_earnings": total_earnings,
        "total_deliveries": total_deliveries,
        "average_per_delivery": total_earnings / total_deliveries if total_deliveries > 0 else 0
    }

# Restaurant Routes
@api_router.get("/restaurants")
async def get_restaurants(user: dict = Depends(get_current_user)):
    restaurants = await db.restaurants.find({}, {"_id": 0}).to_list(1000)
    return restaurants

@api_router.get("/restaurants/{restaurant_id}/analytics")
async def get_restaurant_analytics(restaurant_id: str, user: dict = Depends(get_current_user)):
    if user["role"] == "restaurant" and user.get("restaurant_id") != restaurant_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    orders = await db.orders.find({"restaurant_id": restaurant_id}).to_list(1000)
    
    total_orders = len(orders)
    completed_orders = [o for o in orders if o["status"] == "delivered"]
    total_revenue = sum(o.get("total_amount", 0) for o in completed_orders)
    
    return {
        "total_orders": total_orders,
        "completed_orders": len(completed_orders),
        "total_revenue": total_revenue,
        "average_order_value": total_revenue / len(completed_orders) if completed_orders else 0
    }

# Message Routes
@api_router.post("/messages")
async def create_message(msg: MessageCreate, user: dict = Depends(get_current_user)):
    message_doc = {
        "order_id": msg.order_id,
        "sender_id": user["_id"],
        "sender_name": user["name"],
        "sender_role": user["role"],
        "message": msg.message,
        "created_at": datetime.now(timezone.utc)
    }
    
    result = await db.messages.insert_one(message_doc)
    message_doc["id"] = str(result.inserted_id)
    message_doc.pop("_id", None)
    return message_doc

@api_router.get("/messages/{order_id}")
async def get_messages(order_id: str, user: dict = Depends(get_current_user)):
    messages = await db.messages.find(
        {"order_id": order_id},
        {"_id": 0}
    ).sort("created_at", 1).to_list(1000)
    
    return messages

# Analytics Routes
@api_router.get("/analytics/admin")
async def get_admin_analytics(user: dict = Depends(get_current_user)):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Only admins can view analytics")
    
    total_orders = await db.orders.count_documents({})
    total_couriers = await db.users.count_documents({"role": "courier"})
    total_restaurants = await db.restaurants.count_documents({})
    
    completed_orders = await db.orders.find({"status": "delivered"}).to_list(1000)
    total_revenue = sum(o.get("total_amount", 0) for o in completed_orders)
    
    active_orders = await db.orders.count_documents({
        "status": {"$in": ["pending", "assigned", "picked_up", "in_transit"]}
    })
    
    return {
        "total_orders": total_orders,
        "active_orders": active_orders,
        "total_couriers": total_couriers,
        "total_restaurants": total_restaurants,
        "total_revenue": total_revenue,
        "completed_deliveries": len(completed_orders)
    }

# Startup event to seed admin and create indexes
@app.on_event("startup")
async def startup_event():
    # Create indexes
    await db.users.create_index("email", unique=True)
    await db.login_attempts.create_index("identifier")
    await db.orders.create_index("id")
    await db.orders.create_index("status")
    await db.orders.create_index("courier_id")
    await db.orders.create_index("restaurant_id")
    
    # Seed admin
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@getir-heri.com")
    admin_password = os.environ.get("ADMIN_PASSWORD", "admin123")
    
    existing_admin = await db.users.find_one({"email": admin_email})
    if existing_admin is None:
        hashed = hash_password(admin_password)
        await db.users.insert_one({
            "email": admin_email,
            "password_hash": hashed,
            "name": "Admin",
            "role": "admin",
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc)
        })
        logging.info(f"Admin user created: {admin_email}")
    elif not verify_password(admin_password, existing_admin["password_hash"]):
        await db.users.update_one(
            {"email": admin_email},
            {"$set": {"password_hash": hash_password(admin_password)}}
        )
        logging.info(f"Admin password updated")
    
    # Seed test users
    test_courier_email = "courier@test.com"
    test_courier = await db.users.find_one({"email": test_courier_email})
    if not test_courier:
        await db.users.insert_one({
            "email": test_courier_email,
            "password_hash": hash_password("courier123"),
            "name": "Test Courier",
            "role": "courier",
            "phone": "+905551234567",
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc)
        })
    
    test_restaurant_email = "restaurant@test.com"
    test_restaurant = await db.users.find_one({"email": test_restaurant_email})
    if not test_restaurant:
        # Create restaurant
        restaurant_doc = {
            "name": "Test Restaurant",
            "owner_email": test_restaurant_email,
            "address": "İstanbul, Türkiye",
            "phone": "+905559876543",
            "created_at": datetime.now(timezone.utc)
        }
        restaurant_result = await db.restaurants.insert_one(restaurant_doc)
        restaurant_id = str(restaurant_result.inserted_id)
        
        await db.users.insert_one({
            "email": test_restaurant_email,
            "password_hash": hash_password("restaurant123"),
            "name": "Test Restaurant Owner",
            "role": "restaurant",
            "phone": "+905559876543",
            "restaurant_id": restaurant_id,
            "restaurant_name": "Test Restaurant",
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc)
        })
    
    # Write credentials to memory
    credentials_content = f"""# Test Credentials for getir-heri

## Admin Account
- Email: {admin_email}
- Password: {admin_password}
- Role: admin

## Test Courier Account
- Email: courier@test.com
- Password: courier123
- Role: courier

## Test Restaurant Account
- Email: restaurant@test.com
- Password: restaurant123
- Role: restaurant

## Auth Endpoints
- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/logout
- GET /api/auth/me
- POST /api/auth/refresh
"""
    
    Path("/app/memory").mkdir(exist_ok=True)
    Path("/app/memory/test_credentials.md").write_text(credentials_content)

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=[os.environ.get("FRONTEND_URL", "http://localhost:3000")],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
