# 🚀 getir-heri - Firebase Deployment Hazır

## ✅ Tamamlanan Hazırlıklar

### 1. Firebase Konfigürasyonu
- ✅ `firebase.json` - Hosting ayarları
- ✅ `.firebaserc` - Proje ayarları  
- ✅ Production build hazır (`/app/frontend/build`)
- ✅ SPA routing ve cache headers yapılandırıldı

### 2. Environment Ayarları
- ✅ Backend CORS: `https://kurye-app05.web.app` eklendi
- ✅ Production .env dosyası oluşturuldu
- ✅ API endpoints doğru yapılandırıldı

### 3. Build Detayları
```
Build Boyutu:
- JavaScript: 180.06 kB (gzipped)
- CSS: 10.02 kB (gzipped)
- Lokasyon: /app/frontend/build
```

## 📋 Firebase'e Deploy Adımları

### Yöntem 1: Otomatik Deploy Script

```bash
cd /app
bash deploy.sh
```

### Yöntem 2: Manuel Deploy

```bash
# 1. Firebase CLI kurulumu (eğer yoksa)
npm install -g firebase-tools

# 2. Firebase'e giriş
firebase login

# 3. Projeyi başlat
cd /app/frontend
firebase init hosting

# Sorulara cevaplar:
# - Proje: kurye-app05
# - Public directory: build
# - Single-page app: Yes
# - Overwrite: No

# 4. Deploy et
firebase deploy --only hosting
```

### Yöntem 3: Firebase Console'dan Manuel Upload

1. https://console.firebase.google.com/ adresine gidin
2. kurye-app05 projesini açın
3. Hosting bölümüne gidin
4. `/app/frontend/build` klasörünü upload edin

## ⚙️ Google Maps API Yapılandırması

Google Cloud Console'da API key'iniz için şu domain'leri ekleyin:

1. https://console.cloud.google.com/apis/credentials adresine gidin
2. API key'inizi seçin: `AIzaSyDhzdQbR-ry36TEOP_v7NqbalsEHOmvVgM`
3. **Application restrictions** → **HTTP referrers (web sites)**
4. Şu referrer'ları ekleyin:
```
https://kurye-app05.web.app/*
https://kurye-app05.firebaseapp.com/*
http://localhost:3000/*
```

## 🌐 Deployment Sonrası URL'ler

- **Frontend:** https://kurye-app05.web.app
- **Backend API:** https://courier-system-10.preview.emergentagent.com
- **MongoDB:** Emergent'te (backend üzerinden)

## 🧪 Test Hesapları

Deployment sonrası şu hesaplarla test edin:

```
Admin:
Email: admin@getir-heri.com
Şifre: admin123

Kurye:
Email: courier@test.com
Şifre: courier123

Restoran:
Email: restaurant@test.com
Şifre: restaurant123
```

## 📱 Özellikler

✅ **Multi-Role Sistem:**
- Admin panel (masaüstü)
- Kurye app (mobil-first)
- Restoran panel (masaüstü)

✅ **Google Maps:**
- Canlı konum takibi
- Rota haritaları
- Navigasyon entegrasyonu

✅ **Geolocation:**
- Otomatik kurye konumu
- Backend'e gerçek zamanlı güncelleme
- High accuracy GPS tracking

✅ **Güvenlik:**
- JWT authentication
- httpOnly cookies
- Rol-bazlı erişim kontrolü
- Brute force protection

## 🔄 Güncelleme Süreci

Kod değişikliği yaptıktan sonra:

```bash
cd /app/frontend
yarn build
firebase deploy --only hosting
```

veya

```bash
bash /app/deploy.sh
```

## 📞 Destek

Sorun yaşarsanız:
1. Backend logları: `tail -f /var/log/supervisor/backend.*.log`
2. Build logları: `cd /app/frontend && yarn build`
3. Firebase deploy logları Firebase Console'dan takip edilebilir

## 🎯 Production Checklist

- [x] Firebase konfigürasyonu
- [x] Production build
- [x] CORS ayarları
- [x] Environment variables
- [ ] Google Maps API domain whitelist (Manuel - sizin yapmanız gerekiyor)
- [ ] Firebase deploy (Manuel - sizin yapmanız gerekiyor)
- [ ] SSL sertifikası (Firebase otomatik sağlar)
- [ ] Test ve doğrulama

---

**Hazır!** Artık `/app/frontend/build` klasöründeki dosyaları Firebase'e deploy edebilirsiniz.
