import React, { useEffect, useRef } from 'react';
import { APIProvider, Map, Marker } from '@vis.gl/react-google-maps';

const GOOGLE_MAPS_API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;

export function SimpleMap({ center, markers = [], zoom = 14, height = '400px' }) {
  return (
    <APIProvider apiKey={GOOGLE_MAPS_API_KEY}>
      <div style={{ height, width: '100%' }}>
        <Map
          defaultCenter={center}
          defaultZoom={zoom}
          gestureHandling="greedy"
          disableDefaultUI={false}
          mapId="getir-heri-map"
        >
          {markers.map((marker, index) => (
            <Marker
              key={index}
              position={marker.position}
              title={marker.title}
            />
          ))}
        </Map>
      </div>
    </APIProvider>
  );
}

export function RouteMap({ pickup, delivery, courierLocation, height = '500px' }) {
  const markers = [];

  if (pickup) {
    markers.push({
      position: pickup,
      title: 'Alış Noktası'
    });
  }

  if (delivery) {
    markers.push({
      position: delivery,
      title: 'Teslimat Adresi'
    });
  }

  if (courierLocation) {
    markers.push({
      position: courierLocation,
      title: 'Kurye Konumu'
    });
  }

  const center = courierLocation || pickup || delivery || { lat: 41.0082, lng: 28.9784 };

  return <SimpleMap center={center} markers={markers} zoom={13} height={height} />;
}

export function LiveTrackingMap({ orderId, pickup, delivery, onLocationUpdate }) {
  const [courierLocation, setCourierLocation] = React.useState(null);
  const intervalRef = useRef(null);

  useEffect(() => {
    // Simulated real-time tracking - In production, use WebSocket or polling
    intervalRef.current = setInterval(() => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const newLocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            setCourierLocation(newLocation);
            if (onLocationUpdate) {
              onLocationUpdate(newLocation);
            }
          },
          (error) => console.error('Location error:', error),
          { enableHighAccuracy: true }
        );
      }
    }, 10000); // Update every 10 seconds

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [orderId, onLocationUpdate]);

  return (
    <RouteMap
      pickup={pickup}
      delivery={delivery}
      courierLocation={courierLocation}
      height="400px"
    />
  );
}