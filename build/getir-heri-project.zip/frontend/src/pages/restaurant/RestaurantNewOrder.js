import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { RestaurantLayout } from '../../components/RestaurantLayout';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function RestaurantNewOrder() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    customer_address: '',
    customer_lat: 41.0082,
    customer_lng: 28.9784,
    pickup_address: user.restaurant_name ? `${user.restaurant_name}, İstanbul` : '',
    pickup_lat: 41.0082,
    pickup_lng: 28.9784,
    items: [{ name: '', quantity: 1, price: 0 }],
    total_amount: 0,
    delivery_fee: 25,
    notes: ''
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = field === 'price' || field === 'quantity' ? parseFloat(value) || 0 : value;
    const total = newItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    setFormData(prev => ({ ...prev, items: newItems, total_amount: total }));
  };

  const addItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { name: '', quantity: 1, price: 0 }]
    }));
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    const total = newItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    setFormData(prev => ({ ...prev, items: newItems, total_amount: total }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(
        `${API_URL}/api/orders`,
        {
          ...formData,
          restaurant_id: user.restaurant_id
        },
        { withCredentials: true }
      );
      toast.success('Sipariş oluşturuldu!');
      navigate('/restaurant/orders');
    } catch (error) {
      toast.error('Sipariş oluşturulamadı');
    } finally {
      setLoading(false);
    }
  };

  return (
    <RestaurantLayout>
      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Yeni Sipariş Oluştur</h2>
          <p className="text-sm text-muted-foreground mt-1">Teslimat siparişi oluşturun</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Customer Info */}
          <Card className="border-border/40">
            <CardHeader>
              <CardTitle className="text-base">Müşteri Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="customer_name" data-testid="label-customer-name">Ad Soyad</Label>
                  <Input
                    id="customer_name"
                    value={formData.customer_name}
                    onChange={(e) => handleChange('customer_name', e.target.value)}
                    required
                    data-testid="input-customer-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="customer_phone" data-testid="label-customer-phone">Telefon</Label>
                  <Input
                    id="customer_phone"
                    type="tel"
                    value={formData.customer_phone}
                    onChange={(e) => handleChange('customer_phone', e.target.value)}
                    required
                    data-testid="input-customer-phone"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="customer_address" data-testid="label-customer-address">Teslimat Adresi</Label>
                <Textarea
                  id="customer_address"
                  value={formData.customer_address}
                  onChange={(e) => handleChange('customer_address', e.target.value)}
                  required
                  data-testid="input-customer-address"
                />
              </div>
            </CardContent>
          </Card>

          {/* Order Items */}
          <Card className="border-border/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Ürünler</CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addItem} data-testid="add-item-button">
                  + Ürün Ekle
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.items.map((item, index) => (
                <div key={index} className="flex gap-4 items-end" data-testid={`item-row-${index}`}>
                  <div className="flex-1 space-y-2">
                    <Label htmlFor={`item_name_${index}`}>Ürün Adı</Label>
                    <Input
                      id={`item_name_${index}`}
                      value={item.name}
                      onChange={(e) => handleItemChange(index, 'name', e.target.value)}
                      required
                      data-testid={`input-item-name-${index}`}
                    />
                  </div>
                  <div className="w-24 space-y-2">
                    <Label htmlFor={`item_quantity_${index}`}>Adet</Label>
                    <Input
                      id={`item_quantity_${index}`}
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                      required
                      data-testid={`input-item-quantity-${index}`}
                    />
                  </div>
                  <div className="w-32 space-y-2">
                    <Label htmlFor={`item_price_${index}`}>Fiyat (₺)</Label>
                    <Input
                      id={`item_price_${index}`}
                      type="number"
                      step="0.01"
                      min="0"
                      value={item.price}
                      onChange={(e) => handleItemChange(index, 'price', e.target.value)}
                      required
                      data-testid={`input-item-price-${index}`}
                    />
                  </div>
                  {formData.items.length > 1 && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      onClick={() => removeItem(index)}
                      data-testid={`remove-item-${index}`}
                    >
                      ×
                    </Button>
                  )}
                </div>
              ))}
              <div className="pt-4 border-t border-border/40">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Toplam:</span>
                  <span className="text-xl font-bold">₺{formData.total_amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-sm text-muted-foreground">Teslimat Ücreti:</span>
                  <span className="text-sm font-semibold">₺{formData.delivery_fee.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          <Card className="border-border/40">
            <CardHeader>
              <CardTitle className="text-base">Notlar (Opsiyonel)</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                placeholder="Sipariş notları..."
                data-testid="input-notes"
              />
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/restaurant/orders')}
              data-testid="cancel-button"
            >
              İptal
            </Button>
            <Button type="submit" disabled={loading} className="flex-1" data-testid="submit-order-button">
              {loading ? 'Oluşturuluyor...' : 'Sipariş Oluştur'}
            </Button>
          </div>
        </form>
      </div>
    </RestaurantLayout>
  );
}