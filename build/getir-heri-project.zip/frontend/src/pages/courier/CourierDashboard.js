import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Motorcycle, MapPin, CurrencyDollar, Package, SignOut, ClockCounterClockwise } from '@phosphor-icons/react';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function CourierDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [earnings, setEarnings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('available');

  useEffect(() => {
    fetchOrders();
    fetchEarnings();
  }, []);

  const fetchOrders = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/orders`, {
        withCredentials: true
      });
      setOrders(data);
    } catch (error) {
      toast.error('Siparişler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const fetchEarnings = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/couriers/${user._id}/earnings`, {
        withCredentials: true
      });
      setEarnings(data);
    } catch (error) {
      console.error('Earnings fetch error:', error);
    }
  };

  const handleAcceptOrder = async (orderId) => {
    try {
      await axios.post(
        `${API_URL}/api/orders/${orderId}/accept`,
        {},
        { withCredentials: true }
      );
      toast.success('Sipariş kabul edildi!');
      fetchOrders();
    } catch (error) {
      toast.error('Sipariş kabul edilemedi');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const availableOrders = orders.filter(o => o.status === 'pending');
  const myOrders = orders.filter(o => o.courier_id === user._id && o.status !== 'delivered' && o.status !== 'cancelled');

  const getStatusBadge = (status) => {
    const variants = {
      pending: { label: 'Bekliyor', className: 'bg-amber-100 text-amber-800 border-amber-200' },
      assigned: { label: 'Atandı', className: 'bg-blue-100 text-blue-800 border-blue-200' },
      picked_up: { label: 'Alındı', className: 'bg-purple-100 text-purple-800 border-purple-200' },
      in_transit: { label: 'Yolda', className: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
      delivered: { label: 'Teslim Edildi', className: 'bg-green-100 text-green-800 border-green-200' }
    };
    const variant = variants[status] || variants.pending;
    return <Badge className={variant.className} variant="outline">{variant.label}</Badge>;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Top Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-border/40">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-sm bg-primary flex items-center justify-center">
                <Motorcycle size={24} weight="bold" className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold">getir-heri</h1>
                <p className="text-xs text-muted-foreground">{user.name}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              data-testid="courier-logout-button"
            >
              <SignOut size={20} />
            </Button>
          </div>
        </div>
      </div>

      {/* Earnings Card */}
      {earnings && (
        <div className="p-4" data-testid="courier-earnings-card">
          <Card className="border-border/40 bg-gradient-to-br from-primary/5 to-primary/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Toplam Kazanç</p>
                  <p className="text-3xl font-bold mt-1">₺{earnings.total_earnings.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {earnings.total_deliveries} teslimat
                  </p>
                </div>
                <div className="h-14 w-14 rounded-sm bg-primary flex items-center justify-center">
                  <CurrencyDollar size={32} weight="bold" className="text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tabs */}
      <div className="px-4 mb-4">
        <div className="flex gap-2 border-b border-border/40">
          <button
            onClick={() => setActiveTab('available')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-all duration-200 ${
              activeTab === 'available'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
            data-testid="tab-available-orders"
          >
            Müsait Siparişler ({availableOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('my-orders')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-all duration-200 ${
              activeTab === 'my-orders'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
            data-testid="tab-my-orders"
          >
            Siparişlerim ({myOrders.length})
          </button>
        </div>
      </div>

      {/* Orders Feed */}
      <div className="px-4 pb-24 space-y-4">
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          </div>
        ) : activeTab === 'available' ? (
          availableOrders.length === 0 ? (
            <Card className="border-border/40">
              <CardContent className="p-8 text-center">
                <Package size={48} className="mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Müsait sipariş bulunmuyor</p>
              </CardContent>
            </Card>
          ) : (
            availableOrders.map((order) => (
              <Card key={order.id} className="border-border/40 hover:shadow-sm transition-all duration-200" data-testid={`available-order-${order.id}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base">{order.restaurant_name}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{order.pickup_address}</p>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin size={18} className="text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{order.customer_name}</p>
                      <p className="text-sm text-muted-foreground">{order.customer_address}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-border/40">
                    <div>
                      <p className="text-xs text-muted-foreground">Teslimat Ücreti</p>
                      <p className="text-lg font-bold text-primary">₺{order.delivery_fee.toFixed(2)}</p>
                    </div>
                    <Button
                      onClick={() => handleAcceptOrder(order.id)}
                      className="bg-primary hover:bg-primary/90"
                      data-testid={`accept-order-${order.id}`}
                    >
                      Kabul Et
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )
        ) : (
          myOrders.length === 0 ? (
            <Card className="border-border/40">
              <CardContent className="p-8 text-center">
                <Package size={48} className="mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Aktif siparişiniz bulunmuyor</p>
              </CardContent>
            </Card>
          ) : (
            myOrders.map((order) => (
              <Card
                key={order.id}
                className="border-border/40 hover:shadow-sm transition-all duration-200 cursor-pointer active:scale-95"
                onClick={() => navigate(`/courier/orders/${order.id}`)}
                data-testid={`my-order-${order.id}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base">{order.restaurant_name}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{order.pickup_address}</p>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin size={18} className="text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{order.customer_name}</p>
                      <p className="text-sm text-muted-foreground">{order.customer_address}</p>
                      <p className="text-xs text-muted-foreground mt-1">{order.customer_phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-border/40">
                    <div>
                      <p className="text-xs text-muted-foreground">Teslimat Ücreti</p>
                      <p className="text-lg font-bold text-primary">₺{order.delivery_fee.toFixed(2)}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Detayları Gör →
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border/40 z-50">
        <div className="flex items-center justify-around px-4 py-3">
          <button
            onClick={() => navigate('/courier/dashboard')}
            className="flex flex-col items-center gap-1 text-primary"
            data-testid="nav-dashboard"
          >
            <Package size={24} weight="bold" />
            <span className="text-xs font-medium">Siparişler</span>
          </button>
          <button
            onClick={() => navigate('/courier/history')}
            className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-all duration-200"
            data-testid="nav-history"
          >
            <ClockCounterClockwise size={24} />
            <span className="text-xs">Geçmiş</span>
          </button>
          <button
            onClick={() => navigate('/courier/earnings')}
            className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-all duration-200"
            data-testid="nav-earnings"
          >
            <CurrencyDollar size={24} />
            <span className="text-xs">Kazançlar</span>
          </button>
        </div>
      </div>
    </div>
  );
}
