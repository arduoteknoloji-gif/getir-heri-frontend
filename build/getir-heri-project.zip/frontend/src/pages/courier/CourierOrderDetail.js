import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { ArrowLeft, MapPin, Phone, Package, Storefront, Compass } from '@phosphor-icons/react';
import { toast } from 'sonner';
import { RouteMap } from '../../components/MapComponents';
import { useGeolocation } from '../../hooks/useGeolocation';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function CourierOrderDetail() {
  const { orderId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const { location: courierLocation } = useGeolocation();

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  useEffect(() => {
    // Update courier location to backend
    if (courierLocation && order && order.status !== 'delivered') {
      updateCourierLocation(courierLocation);
    }
  }, [courierLocation, order]);

  const updateCourierLocation = async (location) => {
    try {
      await axios.patch(
        `${API_URL}/api/couriers/${user._id}/location`,
        { lat: location.lat, lng: location.lng },
        { withCredentials: true }
      );
    } catch (error) {
      console.error('Location update error:', error);
    }
  };

  const fetchOrder = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/orders/${orderId}`, {
        withCredentials: true
      });
      setOrder(data);
    } catch (error) {
      toast.error('Sipariş yüklenemedi');
      navigate('/courier/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (newStatus) => {
    setUpdating(true);
    try {
      await axios.patch(
        `${API_URL}/api/orders/${orderId}`,
        { status: newStatus },
        { withCredentials: true }
      );
      toast.success('Durum güncellendi');
      fetchOrder();
    } catch (error) {
      toast.error('Durum güncellenemedi');
    } finally {
      setUpdating(false);
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      assigned: { label: 'Atandı', className: 'bg-blue-100 text-blue-800 border-blue-200' },
      picked_up: { label: 'Alındı', className: 'bg-purple-100 text-purple-800 border-purple-200' },
      in_transit: { label: 'Yolda', className: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
      delivered: { label: 'Teslim Edildi', className: 'bg-green-100 text-green-800 border-green-200' }
    };
    const variant = variants[status] || variants.assigned;
    return <Badge className={variant.className} variant="outline">{variant.label}</Badge>;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!order) return null;

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-border/40">
        <div className="px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/courier/dashboard')}
              data-testid="back-button"
            >
              <ArrowLeft size={20} />
            </Button>
            <div className="flex-1">
              <h1 className="text-lg font-bold">Sipariş Detayları</h1>
              <p className="text-xs text-muted-foreground">#{order.id}</p>
            </div>
            {getStatusBadge(order.status)}
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Map */}
        <Card className="border-border/40 overflow-hidden" data-testid="order-map-card">
          <CardContent className="p-0">
            <RouteMap
              pickup={{ lat: order.pickup_lat, lng: order.pickup_lng }}
              delivery={{ lat: order.customer_lat, lng: order.customer_lng }}
              courierLocation={courierLocation ? { lat: courierLocation.lat, lng: courierLocation.lng } : null}
              height="300px"
            />
          </CardContent>
        </Card>

        {/* Navigation Button */}
        {courierLocation && (
          <Button
            className="w-full bg-blue-600 hover:bg-blue-700"
            onClick={() => {
              const destination = order.status === 'assigned' 
                ? `${order.pickup_lat},${order.pickup_lng}`
                : `${order.customer_lat},${order.customer_lng}`;
              window.open(`https://www.google.com/maps/dir/?api=1&origin=${courierLocation.lat},${courierLocation.lng}&destination=${destination}&travelmode=driving`, '_blank');
            }}
            data-testid="navigate-button"
          >
            <Compass size={18} className="mr-2" weight="bold" />
            Navigasyonu Başlat
          </Button>
        )}

        {/* Status Update */}
        <Card className="border-border/40" data-testid="status-update-card">
          <CardHeader>
            <CardTitle className="text-base">Sipariş Durumu</CardTitle>
          </CardHeader>
          <CardContent>
            <Select
              value={order.status}
              onValueChange={updateStatus}
              disabled={updating || order.status === 'delivered'}
              data-testid="status-select"
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="assigned">Atandı</SelectItem>
                <SelectItem value="picked_up">Alındı</SelectItem>
                <SelectItem value="in_transit">Yolda</SelectItem>
                <SelectItem value="delivered">Teslim Edildi</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Restaurant Info */}
        <Card className="border-border/40" data-testid="restaurant-info-card">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Storefront size={20} className="text-primary" />
              <CardTitle className="text-base">Restoran</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="font-semibold">{order.restaurant_name}</p>
            <div className="flex items-start gap-2 mt-2">
              <MapPin size={16} className="text-muted-foreground mt-0.5" />
              <p className="text-sm text-muted-foreground">{order.pickup_address}</p>
            </div>
          </CardContent>
        </Card>

        {/* Customer Info */}
        <Card className="border-border/40" data-testid="customer-info-card">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Package size={20} className="text-primary" />
              <CardTitle className="text-base">Müşteri</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="font-semibold">{order.customer_name}</p>
            <div className="flex items-start gap-2">
              <MapPin size={16} className="text-muted-foreground mt-0.5" />
              <p className="text-sm text-muted-foreground">{order.customer_address}</p>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-muted-foreground" />
              <a href={`tel:${order.customer_phone}`} className="text-sm text-primary hover:underline">
                {order.customer_phone}
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Order Items */}
        <Card className="border-border/40" data-testid="order-items-card">
          <CardHeader>
            <CardTitle className="text-base">Sipariş İçeriği</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {order.items.map((item, index) => (
                <div key={index} className="flex justify-between text-sm">
                  <span>{item.name} x{item.quantity}</span>
                  <span className="font-medium">₺{item.price?.toFixed(2)}</span>
                </div>
              ))}
              <div className="pt-2 mt-2 border-t border-border/40 space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Ara Toplam</span>
                  <span>₺{order.total_amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold">
                  <span>Teslimat Ücreti</span>
                  <span className="text-primary">₺{order.delivery_fee.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {order.notes && (
          <Card className="border-border/40">
            <CardHeader>
              <CardTitle className="text-base">Notlar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{order.notes}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}