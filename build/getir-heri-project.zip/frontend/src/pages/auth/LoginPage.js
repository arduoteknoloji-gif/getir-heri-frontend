import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Motorcycle } from '@phosphor-icons/react';
import { toast } from 'sonner';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await login(email, password);

    if (result.success) {
      toast.success('Giriş başarılı!');
      if (result.data.role === 'courier') {
        navigate('/courier/dashboard');
      } else if (result.data.role === 'admin') {
        navigate('/admin/dashboard');
      } else if (result.data.role === 'restaurant') {
        navigate('/restaurant/dashboard');
      }
    } else {
      toast.error(result.error);
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-white to-zinc-50 p-4">
      <Card className="w-full max-w-md border-border/40">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="h-16 w-16 rounded-sm bg-primary flex items-center justify-center">
              <Motorcycle size={32} weight="bold" className="text-white" />
            </div>
          </div>
          <div>
            <CardTitle className="text-3xl font-bold">getir-heri</CardTitle>
            <CardDescription className="mt-2">Kurye yönetim sistemine giriş yapın</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" data-testid="login-email-label">E-posta</Label>
              <Input
                id="email"
                type="email"
                placeholder="ornek@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="login-email-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" data-testid="login-password-label">Şifre</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="login-password-input"
              />
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={loading}
              data-testid="login-submit-button"
            >
              {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
            </Button>
          </form>
          <div className="mt-6 text-center text-sm">
            <span className="text-muted-foreground">Hesabınız yok mu? </span>
            <Link to="/register" className="text-primary hover:underline" data-testid="register-link">
              Kayıt Ol
            </Link>
          </div>
          <div className="mt-6 pt-6 border-t border-border/40">
            <p className="text-xs text-muted-foreground text-center mb-2">Test hesapları:</p>
            <div className="text-xs space-y-1">
              <p><strong>Admin:</strong> admin@getir-heri.com / admin123</p>
              <p><strong>Kurye:</strong> courier@test.com / courier123</p>
              <p><strong>Restoran:</strong> restaurant@test.com / restaurant123</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}