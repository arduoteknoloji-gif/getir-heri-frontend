import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Motorcycle } from '@phosphor-icons/react';
import { toast } from 'sonner';

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    role: 'courier',
    phone: '',
    restaurant_name: ''
  });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await register(formData);

    if (result.success) {
      toast.success('Kayıt başarılı!');
      if (result.data.role === 'courier') {
        navigate('/courier/dashboard');
      } else if (result.data.role === 'admin') {
        navigate('/admin/dashboard');
      } else if (result.data.role === 'restaurant') {
        navigate('/restaurant/dashboard');
      }
    } else {
      toast.error(result.error);
    }

    setLoading(false);
  };

  const handleChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-white to-zinc-50 p-4">
      <Card className="w-full max-w-md border-border/40">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="h-16 w-16 rounded-sm bg-primary flex items-center justify-center">
              <Motorcycle size={32} weight="bold" className="text-white" />
            </div>
          </div>
          <div>
            <CardTitle className="text-3xl font-bold">getir-heri</CardTitle>
            <CardDescription className="mt-2">Hesap oluşturun</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" data-testid="register-name-label">Ad Soyad</Label>
              <Input
                id="name"
                type="text"
                placeholder="Ahmet Yılmaz"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                required
                data-testid="register-name-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" data-testid="register-email-label">E-posta</Label>
              <Input
                id="email"
                type="email"
                placeholder="ornek@email.com"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                required
                data-testid="register-email-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" data-testid="register-password-label">Şifre</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => handleChange('password', e.target.value)}
                required
                data-testid="register-password-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" data-testid="register-phone-label">Telefon</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+90 555 123 4567"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                data-testid="register-phone-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role" data-testid="register-role-label">Rol</Label>
              <Select
                value={formData.role}
                onValueChange={(value) => handleChange('role', value)}
                data-testid="register-role-select"
              >
                <SelectTrigger data-testid="register-role-trigger">
                  <SelectValue placeholder="Rol seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="courier" data-testid="role-option-courier">Kurye</SelectItem>
                  <SelectItem value="restaurant" data-testid="role-option-restaurant">Restoran</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.role === 'restaurant' && (
              <div className="space-y-2">
                <Label htmlFor="restaurant_name" data-testid="register-restaurant-name-label">Restoran Adı</Label>
                <Input
                  id="restaurant_name"
                  type="text"
                  placeholder="Leziz Restoran"
                  value={formData.restaurant_name}
                  onChange={(e) => handleChange('restaurant_name', e.target.value)}
                  required
                  data-testid="register-restaurant-name-input"
                />
              </div>
            )}
            <Button
              type="submit"
              className="w-full"
              disabled={loading}
              data-testid="register-submit-button"
            >
              {loading ? 'Kayıt yapılıyor...' : 'Kayıt Ol'}
            </Button>
          </form>
          <div className="mt-6 text-center text-sm">
            <span className="text-muted-foreground">Zaten hesabınız var mı? </span>
            <Link to="/login" className="text-primary hover:underline" data-testid="login-link">
              Giriş Yap
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}