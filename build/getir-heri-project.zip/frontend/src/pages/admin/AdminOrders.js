import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import axios from 'axios';
import { Card, CardContent } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../components/ui/dialog';
import { MapPin, Phone, Package } from '@phosphor-icons/react';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [couriers, setCouriers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [ordersRes, couriersRes] = await Promise.all([
        axios.get(`${API_URL}/api/orders`, { withCredentials: true }),
        axios.get(`${API_URL}/api/couriers`, { withCredentials: true })
      ]);
      setOrders(ordersRes.data);
      setCouriers(couriersRes.data);
    } catch (error) {
      toast.error('Veriler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const handleAssignCourier = async (orderId, courierId) => {
    try {
      await axios.post(
        `${API_URL}/api/orders/${orderId}/assign?courier_id=${courierId}`,
        {},
        { withCredentials: true }
      );
      toast.success('Kurye atandı');
      setAssignDialogOpen(false);
      fetchData();
    } catch (error) {
      toast.error('Kurye atanamadı');
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      pending: { label: 'Bekliyor', className: 'bg-amber-100 text-amber-800' },
      assigned: { label: 'Atandı', className: 'bg-blue-100 text-blue-800' },
      picked_up: { label: 'Alındı', className: 'bg-purple-100 text-purple-800' },
      in_transit: { label: 'Yolda', className: 'bg-indigo-100 text-indigo-800' },
      delivered: { label: 'Teslim Edildi', className: 'bg-green-100 text-green-800' },
      cancelled: { label: 'İptal', className: 'bg-red-100 text-red-800' }
    };
    const variant = variants[status] || variants.pending;
    return <Badge className={variant.className}>{variant.label}</Badge>;
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Siparişler</h2>
          <p className="text-sm text-muted-foreground mt-1">Tüm siparişleri yönetin</p>
        </div>

        <Card className="border-border/40">
          <CardContent className="p-0">
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sipariş ID</TableHead>
                    <TableHead>Restoran</TableHead>
                    <TableHead>Müşteri</TableHead>
                    <TableHead>Kurye</TableHead>
                    <TableHead>Tutar</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        Henüz sipariş yok
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((order) => (
                      <TableRow key={order.id} data-testid={`order-row-${order.id}`}>
                        <TableCell className="font-mono text-xs">#{order.id.slice(0, 8)}</TableCell>
                        <TableCell className="font-medium">{order.restaurant_name}</TableCell>
                        <TableCell>
                          <div>
                            <p className="text-sm font-medium">{order.customer_name}</p>
                            <p className="text-xs text-muted-foreground">{order.customer_phone}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          {order.courier_name ? (
                            <span className="text-sm">{order.courier_name}</span>
                          ) : (
                            <Badge variant="outline" className="text-xs">Atanmadı</Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-semibold">₺{order.total_amount.toFixed(2)}</TableCell>
                        <TableCell>{getStatusBadge(order.status)}</TableCell>
                        <TableCell>
                          {order.status === 'pending' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedOrder(order);
                                setAssignDialogOpen(true);
                              }}
                              data-testid={`assign-courier-${order.id}`}
                            >
                              Kurye Ata
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Assign Courier Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent data-testid="assign-courier-dialog">
          <DialogHeader>
            <DialogTitle>Kurye Ata</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Kurye Seç</label>
              <Select
                onValueChange={(courierId) => handleAssignCourier(selectedOrder?.id, courierId)}
                data-testid="courier-select"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Kurye seçin" />
                </SelectTrigger>
                <SelectContent>
                  {couriers.map((courier) => (
                    <SelectItem key={courier.email} value={courier.email.replace('@', '_')} data-testid={`courier-option-${courier.email}`}>
                      {courier.name} - {courier.active_orders || 0} aktif sipariş
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
