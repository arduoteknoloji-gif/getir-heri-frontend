import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Package, Motorcycle, Storefront, CurrencyDollar, TrendUp, Clock } from '@phosphor-icons/react';
import { Badge } from '../../components/ui/badge';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function AdminDashboard() {
  const [analytics, setAnalytics] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [analyticsRes, ordersRes] = await Promise.all([
        axios.get(`${API_URL}/api/analytics/admin`, { withCredentials: true }),
        axios.get(`${API_URL}/api/orders`, { withCredentials: true })
      ]);
      setAnalytics(analyticsRes.data);
      setRecentOrders(ordersRes.data.slice(0, 10));
    } catch (error) {
      toast.error('Veriler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      pending: { label: 'Bekliyor', className: 'bg-amber-100 text-amber-800 border-amber-200' },
      assigned: { label: 'Atandı', className: 'bg-blue-100 text-blue-800 border-blue-200' },
      picked_up: { label: 'Alındı', className: 'bg-purple-100 text-purple-800 border-purple-200' },
      in_transit: { label: 'Yolda', className: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
      delivered: { label: 'Teslim Edildi', className: 'bg-green-100 text-green-800 border-green-200' },
      cancelled: { label: 'İptal', className: 'bg-red-100 text-red-800 border-red-200' }
    };
    const variant = variants[status] || variants.pending;
    return <Badge className={variant.className} variant="outline">{variant.label}</Badge>;
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Dashboard</h2>
          <p className="text-sm text-muted-foreground mt-1">Sistem geneline genel bakış</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-border/40" data-testid="stat-total-orders">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Package size={20} className="text-primary" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Toplam Sipariş</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{analytics?.total_orders || 0}</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="stat-active-orders">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Clock size={20} className="text-amber-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Aktif Sipariş</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{analytics?.active_orders || 0}</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="stat-total-couriers">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Motorcycle size={20} className="text-blue-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Kurye</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{analytics?.total_couriers || 0}</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="stat-total-revenue">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <CurrencyDollar size={20} className="text-green-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Toplam Gelir</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">₺{analytics?.total_revenue?.toFixed(2) || '0.00'}</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Orders */}
        <Card className="border-border/40">
          <CardHeader>
            <CardTitle>Son Siparişler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Henüz sipariş yok</p>
              ) : (
                recentOrders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center justify-between p-3 border border-border/40 rounded-sm hover:bg-secondary/50 transition-all duration-200"
                    data-testid={`recent-order-${order.id}`}
                  >
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{order.restaurant_name}</p>
                      <p className="text-xs text-muted-foreground">{order.customer_name} - {order.customer_address}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-bold">₺{order.total_amount.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(order.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                      {getStatusBadge(order.status)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
