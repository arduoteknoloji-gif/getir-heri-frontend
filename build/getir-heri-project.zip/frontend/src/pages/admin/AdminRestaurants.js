import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import axios from 'axios';
import { Card, CardContent } from '../../components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import { Phone, MapPin } from '@phosphor-icons/react';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function AdminRestaurants() {
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/restaurants`, {
        withCredentials: true
      });
      setRestaurants(data);
    } catch (error) {
      toast.error('Restoranlar yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Restoranlar</h2>
          <p className="text-sm text-muted-foreground mt-1">Kayıtlı restoranlar</p>
        </div>

        <Card className="border-border/40">
          <CardContent className="p-0">
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Restoran Adı</TableHead>
                    <TableHead>Sahip E-posta</TableHead>
                    <TableHead>Telefon</TableHead>
                    <TableHead>Adres</TableHead>
                    <TableHead>Kayıt Tarihi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {restaurants.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        Henüz restoran yok
                      </TableCell>
                    </TableRow>
                  ) : (
                    restaurants.map((restaurant, idx) => (
                      <TableRow key={restaurant.id || idx} data-testid={`restaurant-row-${idx}`}>
                        <TableCell className="font-medium">{restaurant.name}</TableCell>
                        <TableCell className="font-mono text-sm">{restaurant.owner_email}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Phone size={14} className="text-muted-foreground" />
                            <span className="text-sm">{restaurant.phone || '-'}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <MapPin size={14} className="text-muted-foreground" />
                            <span className="text-sm">{restaurant.address || '-'}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {restaurant.created_at
                            ? new Date(restaurant.created_at).toLocaleDateString('tr-TR')
                            : '-'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}