import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Package, Motorcycle, Storefront, CurrencyDollar, TrendUp, CheckCircle } from '@phosphor-icons/react';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function AdminAnalytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/analytics/admin`, {
        withCredentials: true
      });
      setAnalytics(data);
    } catch (error) {
      toast.error('Analitik veriler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Analitik</h2>
          <p className="text-sm text-muted-foreground mt-1">Detaylı performans metrikleri</p>
        </div>

        {/* Primary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card className="border-border/40" data-testid="analytics-total-orders">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Package size={20} className="text-primary" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Toplam Sipariş</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{analytics?.total_orders || 0}</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="analytics-completed-deliveries">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <CheckCircle size={20} className="text-green-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Tamamlanan</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{analytics?.completed_deliveries || 0}</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="analytics-total-revenue">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <CurrencyDollar size={20} className="text-green-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Toplam Gelir</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">₺{analytics?.total_revenue?.toFixed(2) || '0.00'}</p>
            </CardContent>
          </Card>
        </div>

        {/* Secondary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="border-border/40" data-testid="analytics-couriers">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Motorcycle size={20} className="text-blue-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Aktif Kurye</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{analytics?.total_couriers || 0}</p>
              <p className="text-sm text-muted-foreground mt-2">Kayıtlı kurye sayısı</p>
            </CardContent>
          </Card>

          <Card className="border-border/40" data-testid="analytics-restaurants">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Storefront size={20} className="text-purple-600" />
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Restoran</p>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{analytics?.total_restaurants || 0}</p>
              <p className="text-sm text-muted-foreground mt-2">Kayıtlı restoran sayısı</p>
            </CardContent>
          </Card>
        </div>

        {/* Performance Card */}
        <Card className="border-border/40 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendUp size={24} className="text-primary" />
              Performans Özeti
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Başarı Oranı</span>
              <span className="text-xl font-bold">
                {analytics?.total_orders > 0
                  ? ((analytics.completed_deliveries / analytics.total_orders) * 100).toFixed(1)
                  : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Ortalama Sipariş Değeri</span>
              <span className="text-xl font-bold">
                ₺{analytics?.completed_deliveries > 0
                  ? (analytics.total_revenue / analytics.completed_deliveries).toFixed(2)
                  : '0.00'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Kurye Başına Sipariş</span>
              <span className="text-xl font-bold">
                {analytics?.total_couriers > 0
                  ? (analytics.completed_deliveries / analytics.total_couriers).toFixed(1)
                  : 0}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}