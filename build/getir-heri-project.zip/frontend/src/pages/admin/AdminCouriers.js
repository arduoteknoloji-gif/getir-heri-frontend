import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import axios from 'axios';
import { Card, CardContent } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import { Phone, Package } from '@phosphor-icons/react';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL;

export default function AdminCouriers() {
  const [couriers, setCouriers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCouriers();
  }, []);

  const fetchCouriers = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/api/couriers`, {
        withCredentials: true
      });
      setCouriers(data);
    } catch (error) {
      toast.error('Kuryeler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Kuryeler</h2>
          <p className="text-sm text-muted-foreground mt-1">Aktif kuryeler ve performansları</p>
        </div>

        <Card className="border-border/40">
          <CardContent className="p-0">
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ad Soyad</TableHead>
                    <TableHead>E-posta</TableHead>
                    <TableHead>Telefon</TableHead>
                    <TableHead>Aktif Sipariş</TableHead>
                    <TableHead>Kayıt Tarihi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {couriers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        Henüz kurye yok
                      </TableCell>
                    </TableRow>
                  ) : (
                    couriers.map((courier) => (
                      <TableRow key={courier.email} data-testid={`courier-row-${courier.email}`}>
                        <TableCell className="font-medium">{courier.name}</TableCell>
                        <TableCell className="font-mono text-sm">{courier.email}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Phone size={14} className="text-muted-foreground" />
                            <span className="text-sm">{courier.phone || '-'}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-blue-50">
                            <Package size={14} className="mr-1" />
                            {courier.active_orders || 0}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {courier.created_at
                            ? new Date(courier.created_at).toLocaleDateString('tr-TR')
                            : '-'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}