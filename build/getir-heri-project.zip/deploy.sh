#!/bin/bash

# getir-heri Firebase Deploy Script

echo "🚀 getir-heri Firebase Deployment başlatılıyor..."

# Frontend klasörüne git
cd /app/frontend || exit 1

# Dependencies kontrolü
echo "📦 Dependencies kontrol ediliyor..."
if [ ! -d "node_modules" ]; then
    echo "📦 Dependencies yükleniyor..."
    yarn install
fi

# Production build
echo "🔨 Production build oluşturuluyor..."
yarn build

if [ $? -ne 0 ]; then
    echo "❌ Build başarısız oldu!"
    exit 1
fi

echo "✅ Build başarılı!"

# Firebase deploy (eğer firebase-tools kuruluysa)
if command -v firebase &> /dev/null; then
    echo "🔥 Firebase'e deploy ediliyor..."
    firebase deploy --only hosting
    
    if [ $? -eq 0 ]; then
        echo "✅ Deploy başarılı!"
        echo "🌐 Site: https://kurye-app05.web.app"
    else
        echo "⚠️  Firebase deploy başarısız. Manuel olarak deploy edin:"
        echo "   cd /app/frontend && firebase deploy --only hosting"
    fi
else
    echo "⚠️  Firebase CLI bulunamadı."
    echo "📝 Build dosyaları hazır: /app/frontend/build"
    echo ""
    echo "Firebase CLI kurulumu:"
    echo "   npm install -g firebase-tools"
    echo "   firebase login"
    echo "   cd /app/frontend"
    echo "   firebase deploy --only hosting"
fi

echo ""
echo "✨ İşlem tamamlandı!"
echo ""
echo "📋 Sonraki adımlar:"
echo "1. Google Cloud Console'da API key'e domain ekleyin:"
echo "   - https://kurye-app05.web.app/*"
echo "   - https://kurye-app05.firebaseapp.com/*"
echo ""
echo "2. Test hesapları:"
echo "   Admin: admin@getir-heri.com / admin123"
echo "   Kurye: courier@test.com / courier123"
echo "   Restoran: restaurant@test.com / restaurant123"