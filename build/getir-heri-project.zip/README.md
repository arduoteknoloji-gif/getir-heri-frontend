# 📦 getir-heri - Kurye Yönetim Sistemi

**Shipday benzeri tam özellikli kurye teslimat yönetim sistemi**

## 🎯 Proje Özeti

getir-heri, kurye teslimat işlemlerini yönetmek için geliştirilmiş çok rollü bir web uygulamasıdır. Restoran sahipleri sipariş oluşturabilir, kuryeler teslimat yapabilir ve adminler tüm sistemi yönetebilir.

### Temel Özellikler

- ✅ **3 Rol-Bazlı Panel:** Admin, Kurye, Restoran
- ✅ **Google Maps Entegrasyonu:** Canlı konum takibi ve navigasyon
- ✅ **Geolocation API:** Otomatik kurye konumu güncelleme
- ✅ **JWT Authentication:** Güvenli oturum yönetimi
- ✅ **Real-time Tracking:** Sipariş ve kurye takibi
- ✅ **Mobil-First:** Kurye uygulaması mobil optimize
- ✅ **Kazanç Raporlama:** Kurye ve restoran analitiği
- ✅ **Türkçe Lokalizasyon:** Tam Türkçe arayüz

## 🏗️ Teknoloji Stack

### Backend
- **Framework:** FastAPI (Python)
- **Database:** MongoDB
- **Authentication:** JWT + bcrypt
- **CORS:** Cross-origin yapılandırılmış

### Frontend
- **Framework:** React 19
- **UI Library:** Shadcn/UI + Tailwind CSS
- **Icons:** Phosphor Icons
- **Maps:** @vis.gl/react-google-maps
- **State Management:** React Context API
- **Routing:** React Router v7
- **HTTP Client:** Axios

## 🚀 Hızlı Başlangıç

### Backend Kurulumu

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend Kurulumu

```bash
cd frontend
yarn install
yarn start
```

## 👥 Test Hesapları

- **Admin:** admin@getir-heri.com / admin123
- **Kurye:** courier@test.com / courier123
- **Restoran:** restaurant@test.com / restaurant123

## 📱 Kullanım Akışı

1. **Restoran** sipariş oluşturur
2. **Kurye** siparişi kabul eder
3. Harita ile navigasyon yapılır
4. Sipariş teslim edilir
5. **Admin** tüm süreci takip eder

## 🌐 Firebase Deployment

```bash
cd frontend
yarn build
firebase deploy --only hosting
```

Detaylı bilgi için `FIREBASE_DEPLOYMENT.md` dosyasına bakın.

## 📞 Destek

Detaylı kurulum ve kullanım talimatları için proje içindeki dokümantasyon dosyalarına bakın:
- `FIREBASE_DEPLOYMENT.md` - Firebase deployment
- `FIREBASE_READY.md` - Quick start guide

---

**⭐ getir-heri - Production Ready Courier Management System**
