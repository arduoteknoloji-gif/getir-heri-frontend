# getir-heri - Firebase Deployment Talimatları

## Ön Gereksinimler

1. Firebase CLI kurulumu:
```bash
npm install -g firebase-tools
```

2. Firebase'e giriş yapın:
```bash
firebase login
```

## Deployment Adımları

### 1. Production Build Oluşturma

```bash
cd /app/frontend
yarn build
```

Bu komut `/app/frontend/build` klasöründe production-ready dosyaları oluşturur.

### 2. Firebase Projesini Başlatma

```bash
cd /app/frontend
firebase init hosting
```

Sorulan sorulara şu şekilde cevap verin:
- **Select a default Firebase project:** kurye-app05 (veya mevcut proje adınız)
- **What do you want to use as your public directory?** build
- **Configure as a single-page app?** Yes
- **Set up automatic builds with GitHub?** No
- **Overwrite build/index.html?** No

### 3. Deploy Etme

```bash
firebase deploy --only hosting
```

Deploy tamamlandığında şu URL'de yayında olacak:
**https://kurye-app05.web.app**

## Backend URL Güncellemesi

Frontend artık Firebase'de olacak ama backend hala Emergent'te çalışıyor.

### Frontend .env.production dosyası oluşturun:

```bash
cat > /app/frontend/.env.production << 'EOF'
REACT_APP_BACKEND_URL=https://courier-system-10.preview.emergentagent.com
REACT_APP_GOOGLE_MAPS_API_KEY=AIzaSyDhzdQbR-ry36TEOP_v7NqbalsEHOmvVgM
EOF
```

### Build'i tekrar alın:

```bash
cd /app/frontend
yarn build
firebase deploy --only hosting
```

## Google Maps API Key Konfigürasyonu

Google Cloud Console'da API key'iniz için:

1. **Application restrictions** → **HTTP referrers**
2. Şu domain'leri ekleyin:
   - `https://kurye-app05.web.app/*`
   - `https://kurye-app05.firebaseapp.com/*`
   - `http://localhost:3000/*` (development için)

## CORS Ayarları

Backend'de Firebase domain'i CORS'a eklendi:
- Frontend URL: `https://kurye-app05.web.app`

## Test Etme

Deploy sonrası şu hesaplarla test edin:

- **Admin:** admin@getir-heri.com / admin123
- **Kurye:** courier@test.com / courier123
- **Restoran:** restaurant@test.com / restaurant123

## Önemli Notlar

1. Her kod değişikliğinde `yarn build` ve `firebase deploy` komutlarını çalıştırın
2. Backend Emergent'te çalışmaya devam edecek
3. MongoDB bağlantısı backend üzerinden olacak
4. Cookie-based authentication çalışması için backend CORS ayarları yapıldı

## Hızlı Deploy Komutu

```bash
cd /app/frontend && yarn build && firebase deploy --only hosting
```

## Production Checklist

- ✅ Firebase domain backend CORS'a eklendi
- ✅ Google Maps API key'e domain eklenmeli (manuel)
- ✅ Production environment variables ayarlandı
- ✅ Build optimizasyonları aktif
- ✅ SPA routing konfigürasyonu yapıldı
- ✅ Asset caching headers eklendi